from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import JSONResponse, RedirectResponse
from langserve import add_routes
from transformers import pipeline, AutoModelForCausalLM, AutoTokenizer
from dotenv import load_dotenv
import torch
import os


from utils.rag_chain import DocumentProcessing
from utils.upload_file import UploadFilesService
from config.settings import UPLOAD_FOLDER

# Initialize components
load_dotenv()
app = FastAPI()
docs_processing = DocumentProcessing()
upload_file_service = UploadFilesService()

# Setup RAG chain
docs_processing.setup_rag()
rag_chain = docs_processing.rag_chain()
add_routes(app, rag_chain, path="/rag_chain")

# Root endpoint
@app.get("/")
async def redirect_root_to_docs():
    return RedirectResponse("/docs")

# Chroma DB endpoints
@app.get("/fetch_docs_for_query/{query}")
def fetch_docs_for_query(query: str):
    try:
        return {"result": docs_processing.qa_chain(query)}
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/fetch_chroma_db")
def read_chroma_db():
    try:
        return JSONResponse({"data": docs_processing.get_chroma_db()})
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/fetch_embeddings")
def fetch_embeddings():
    try:
        return JSONResponse({"data": docs_processing.get_embeddings()})
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/fetch_embeddings_and_data")
def fetch_embeddings_and_data():
    try:
        return JSONResponse({"data": docs_processing.get_embeddings_and_data()})
    except Exception as e:
        raise HTTPException(500, str(e))


# File upload endpoint
@app.post("/upload/")
async def upload_file(file: UploadFile = File(...)):
    if not file:
        raise HTTPException(400, "No file uploaded")
    try:
        saved_path = upload_file_service.save_file(file, UPLOAD_FOLDER)
        return JSONResponse({
            "message": "File uploaded successfully",
            "file_path": saved_path
        }, 200)
    except HTTPException as e:
        raise e

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8054)
