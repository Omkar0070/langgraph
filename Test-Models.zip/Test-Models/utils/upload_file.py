from pathlib import Path
import shutil
from fastapi import UploadFile, HTTPException

class UploadFilesService:
    def save_file(self , file: UploadFile, upload_folder: Path) -> str:
        """
        Save the uploaded file to the specified folder.

        :param file: The uploaded file object.
        :param upload_folder: The folder where the file will be stored.
        :return: The file path of the saved file.
        """
        file_path = upload_folder / file.filename
        try:
            # Ensure the folder exists
            upload_folder.mkdir(parents=True, exist_ok=True)

            # Save the file
            with file_path.open("wb") as buffer:
                shutil.copyfileobj(file.file, buffer)

            return str(file_path)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error saving file: {str(e)}")
