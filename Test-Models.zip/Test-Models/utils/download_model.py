from transformers import AutoModelForCausalLM, AutoTokenizer
from dotenv import load_dotenv
import os
import torch
from huggingface_hub import HfApi, hf_hub_download
from requests.exceptions import ReadTimeout
import time

load_dotenv()

def download_and_load_model():
    model_dir = os.getenv("MODEL_DIR", "./models/deepseek")
    repo_id = os.getenv("DOC_GEN_MODEL_NAME")
    hf_token = os.getenv("HF_API_KEY")
    
    max_retries = 5
    retry_delay = 5  # seconds
    timeout = 30  # Increased timeout

    try:
        # Check if critical files exist (not just directory)
        if not os.path.exists(os.path.join(model_dir, "tokenizer.json")):
            print(f"Downloading model {repo_id} to {model_dir}...")
            os.makedirs(model_dir, exist_ok=True)
            
            # Configure Hugging Face Hub with timeout
            api = HfApi(token=hf_token)
            
            # Retry loop for download
            for attempt in range(max_retries):
                try:
                    # Download tokenizer with timeout
                    tokenizer = AutoTokenizer.from_pretrained(
                        repo_id,
                        token=hf_token,
                        timeout=timeout
                    )
                    
                    # Download model with timeout and retry
                    model = AutoModelForCausalLM.from_pretrained(
                        repo_id,
                        token=hf_token,
                        trust_remote_code=True,
                        torch_dtype="auto",
                        # Removed 'timeout' parameter from model download
                    )
                    break  # Success, exit retry loop
                except ReadTimeout as e:
                    print(f"Attempt {attempt+1} failed. Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
            else:
                raise Exception("Download failed after multiple attempts")
            
            # Save model and tokenizer
            tokenizer.save_pretrained(model_dir)
            model.save_pretrained(model_dir)
            
            # Reload with device mapping
            model = AutoModelForCausalLM.from_pretrained(
                model_dir,
                trust_remote_code=True,
                device_map="cpu"  # Force CPU for stability
            )
            return tokenizer, model

        # Load existing model
        print("Loading model from local directory...")
        tokenizer = AutoTokenizer.from_pretrained(model_dir)
        model = AutoModelForCausalLM.from_pretrained(
            model_dir,
            trust_remote_code=True,
            device_map="cpu"
        )
        return tokenizer, model

    except Exception as e:
        print(f"Model setup failed: {str(e)}")
        raise