from langgraph.graph import StateGraph
from transformers import AutoModelForCausalLM, AutoTokenizer
from sentence_transformers import SentenceTransformer
import chromadb
import glob
import os
from dotenv import load_dotenv
from pydantic import BaseModel
from typing import List
import torch
from unstructured.partition.auto import partition
from utils.download_model import download_and_load_model  # Model download integration

load_dotenv()
hf_api_token = os.getenv("HF_API_KEY")
repo_id = os.getenv("DOC_GEN_MODEL_NAME")

class DocumentProcessing:
    class GraphState(BaseModel):
        query: str
        context: List[str] = []
        answer: str = ""

    def __init__(self):
        self.vectorstore = None
        self.model = None
        self.tokenizer = None
        self.embeddings = SentenceTransformer('all-MiniLM-L6-v2')

    def setup_rag(self):
        try:
            # Load model via dedicated download module
            self.tokenizer, self.model = download_and_load_model()[:2]
            
            # ChromaDB native client setup
            client = chromadb.PersistentClient(path="./shared/db")
            collection = client.get_or_create_collection("docs")
            
            # Process documents
            for file_path in glob.glob("./docs/**/*", recursive=True):
                if not os.path.isfile(file_path):
                    continue
                try:
                    # Native document loading
                    if file_path.endswith(".pdf"):
                        from PyPDF2 import PdfReader
                        reader = PdfReader(file_path)
                        text = "\n".join(page.extract_text() for page in reader.pages)
                    elif file_path.endswith(".docx"):
                        from docx import Document
                        doc = Document(file_path)
                        text = "\n".join(p.text for p in doc.paragraphs)
                    elif file_path.endswith(".txt"):
                        with open(file_path, 'r') as f:
                            text = f.read()
                    elif file_path.endswith((".json", ".xml", ".xlsx", ".xls")):
                        elements = partition(filename=file_path)
                        text = "\n\n".join([str(el) for el in elements])
                    else:
                        continue
                    
                    # Custom text splitting
                    chunks = self._split_text(text)
                    embeddings = self.embeddings.encode(chunks)
                    ids = [f"{file_path}_chunk_{i}" for i in range(len(chunks))]
                    
                    # Add to ChromaDB
                    collection.add(
                        documents=chunks,
                        embeddings=embeddings,
                        ids=ids
                    )
                    
                except Exception as e:
                    print(f"Skipping {file_path}: {str(e)}")
                    continue
            
            self.vectorstore = collection

        except Exception as e:
            print(f"Setup failed: {str(e)}")
            raise

    def _split_text(self, text: str, chunk_size: int = 3000, overlap: int = 0) -> List[str]:
        """Pure Python text splitting without dependencies"""
        words = text.split()
        chunks = []
        for i in range(0, len(words), chunk_size - overlap):
            chunk = ' '.join(words[i:i + chunk_size])
            chunks.append(chunk)
        return chunks

    def retrieve(self, query: str) -> List[str]:
        try:
            query_embedding = self.embeddings.encode([query])
            results = self.vectorstore.query(
                query_embeddings=query_embedding,
                n_results=5
            )
            return results['documents'][0] if results['documents'] else []
        except Exception as e:
            print(f"Retrieval failed: {str(e)}")
            return []

    def generate(self, query: str, context: List[str]) -> str:
        try:
            prompt = f"""<|system|>
            Use the following context to answer concisely:
            {context}
            <|user|>
            {query}
            <|assistant|>
            """
            
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=1024,
                temperature=0.7,
                top_p=0.9,
                repetition_penalty=1.2
            )
            return self.tokenizer.decode(outputs[0], skip_special_tokens=True).strip()
        except Exception as e:
            print(f"Generation failed: {str(e)}")
            return "Error generating response"

    def rag_chain(self):
        graph = StateGraph(self.GraphState)

        def retrieve_node(state: self.GraphState): # type: ignore
            context = self.retrieve(state.query)
            return {"context": context}

        def generate_node(state: self.GraphState): # type: ignore
            answer = self.generate(state.query, state.context)
            return {"answer": answer}

        graph.add_node("retrieve", retrieve_node)
        graph.add_node("generate", generate_node)
        graph.add_edge("retrieve", "generate")
        graph.set_entry_point("retrieve")
        graph.set_finish_point("generate")

        return graph.compile()