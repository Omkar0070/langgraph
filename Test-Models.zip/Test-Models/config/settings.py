from pathlib import Path

# Define the folder where uploaded files will be stored
UPLOAD_FOLDER = Path("docs")
